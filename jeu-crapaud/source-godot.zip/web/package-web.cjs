// Après l'export Godot : node web/package-web.cjs [dossier-de-sortie]
// Le dossier de sortie doit être distinct du dossier exports.
const fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib'),crypto=require('node:crypto');
const project=path.resolve(__dirname,'..'),input=path.join(project,'exports');
const output=path.resolve(process.argv[2]||path.join(project,'web-build'));
if(output===input)throw Error('Choisir un dossier différent de exports.');
fs.mkdirSync(output,{recursive:true});
const hash=b=>crypto.createHash('sha256').update(b).digest('hex').slice(0,12);
const wasm=fs.readFileSync(path.join(input,'index.wasm')),pack=fs.readFileSync(path.join(input,'index.pck'));
for(const file of fs.readdirSync(input))if(file!=='index.wasm'&&fs.statSync(path.join(input,file)).isFile())fs.copyFileSync(path.join(input,file),path.join(output,file));
fs.writeFileSync(path.join(output,'index.wasm.gz'),zlib.gzipSync(wasm,{level:9}));
const html=fs.readFileSync(path.join(output,'index.html'),'utf8').replaceAll('__WASM_HASH__',hash(wasm)).replaceAll('__WASM_BYTES__',String(wasm.length)).replaceAll('__PACK_HASH__',hash(pack));
fs.writeFileSync(path.join(output,'index.html'),html);
fs.copyFileSync(path.join(__dirname,'photo-trigger.js'),path.join(output,'photo-trigger.js'));
console.log('Fichiers Web prêts : '+output);
