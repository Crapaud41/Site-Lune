extends SceneTree

var game: Node
var failures: Array[String] = []

func _initialize() -> void:
	call_deferred("_run")

func frames(n: int) -> void:
	for i in range(n): await physics_frame

func check(ok: bool, label: String) -> void:
	if ok: print("PASS: ",label)
	else:
		failures.append(label)
		push_error(label)

func _run() -> void:
	game = load("res://lantern.tscn").instantiate()
	root.add_child(game)
	game.test_mode = true
	game._start_game()
	await frames(20)
	check(game.player.is_on_floor(),"Murphy se pose au depart")
	check(game.flies.size()==20,"20 lucioles")
	# Real physics all the way, without flight, teleports, or disabled hazards.
	var jumps = [409,568,680,806,934,1120,1217,1339,1545,1654,1773,1885,2350,2490,2585,2695,2815,2935,3040,3128,3292,3460,3590,3708,3950,4200,4290]
	var index = 0
	var approach = 0
	game.test_direction = 1
	for frame in range(6000):
		await physics_frame
		# Land deliberately on the narrow square, then take a full jump to the sill.
		if index == jumps.size():
			if approach == 0 and game.player.position.x >= 4370:
				game.test_direction = 0
				if game.player.is_on_floor():
					approach = 1
					game.test_direction = 1
					game.test_jump = true
			elif approach == 1 and game.player.position.x >= 4448:
				game.test_direction = 0
				if game.player.is_on_floor():
					approach = 2
					game.test_direction = 1
					game.test_jump = true
		if game.player.position.x > 4607: game.test_direction = 0
		if frame%18==0 and game.mode=="play": game._tongue()
		if game.mode in ["home","finish_menu"]: break
		if game.mode == "respawn":
			check(false,"Trajet sans chute, position %s, saut %d"%[game.player.position,index])
			quit(1)
			return
		if index < jumps.size() and game.player.position.x >= jumps[index] and game.player.is_on_floor():
			print("JUMP ",index," ",game.player.position)
			game.test_jump = true
			index += 1
		if frame % 600 == 0: print("POSITION ",game.player.position," jump ",index," approach ",approach)
	check(game.mode == "home","Entree dans la fenetre atteinte sans vol : %s, saut %d"%[game.player.position,index])
	if game.mode != "home":
		quit(1)
		return
	check(game.checkpoint and game.deaths==0,"Point de reprise active en parcourant le niveau")
	check(approach==2,"La petite plateforme carree permet d'atteindre la fenetre")
	print("COLLECTED ",game.score)
	await frames(205)
	check(game.mode=="finish_menu" and game.completed_in_run,"Entree animee et menu final")
	game._reset_level()
	game.test_direction = 0
	await frames(20)
	check(game.score==0 and not game.checkpoint and not game.flight_enabled,"Rejouer reinitialise la partie")
	game.player.position = Vector2(730,320)
	await frames(3)
	check(game.mode=="respawn","L'eau fait perdre")
	await frames(50)
	check(game.mode=="play" and absf(game.player.position.x-game.START.x)<1,"Reprise au debut avant la lanterne")
	game.player.position = Vector2(4000,283)
	game.player.velocity = Vector2.ZERO
	await frames(30)
	check(game.mode=="respawn","La plateforme supprimee ne laisse aucune collision invisible")
	await frames(50)
	game.player.position = game.REST
	await frames(20)
	check(game.checkpoint,"Lanterne allumee")
	game.player.position = Vector2(game.enemies[1].pos.x,282)
	await frames(3)
	check(game.mode=="respawn","Contact lateral avec le putois")
	await frames(50)
	check(absf(game.player.position.x-game.REST.x)<1,"Reprise a la lanterne apres collision")
	game.player.position = Vector2(2805,320)
	await frames(3)
	await frames(50)
	check(absf(game.player.position.x-game.REST.x)<1,"Reprise a la lanterne apres chute")
	for repeat in range(2):
		for digit in [KEY_1,KEY_9,KEY_9,KEY_5]:
			var event = InputEventKey.new()
			event.keycode = digit
			event.pressed = true
			game._input(event)
		check(game.flight_enabled == (repeat==0),"1995 bascule le vol %d"%repeat)
	game.player.position = Vector2(4599,282)
	await frames(8)
	check(game.mode=="play","Passer sous la fenetre ne termine pas le niveau")
	game.score = 0
	game.player.position = Vector2(4610,200)
	await frames(45)
	check(game.mode=="home","On peut rentrer sans toutes les lucioles")
	print("RESULTAT: ","OK" if failures.is_empty() else "ECHEC")
	quit(0 if failures.is_empty() else 1)
