extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var game = load("res://main.tscn").instantiate()
	root.add_child(game)
	game.test_mode = true
	game._start_game()
	game.test_direction = 1
	for frame in range(6000):
		await physics_frame
		if game.mode=="ending":
			print("PASS: parcours complet franchi avec les collisions reelles / chutes = ",game.deaths)
			quit(0)
			return
		if game.mode!="play": continue
		if game.player.is_on_floor():
			var x: float = game.player.position.x
			var foot: float = game.player.position.y+10
			for p in game.platforms:
				var r: Rect2 = p.rect
				if x>=r.position.x and x<=r.end.x and absf(foot-r.position.y)<4 and r.end.x-x<29:
					game.test_jump = true
				if p.kind=="stump" and r.position.x-x>0 and r.position.x-x<35:
					game.test_jump = true
			for e in game.enemies:
				if e.alive and e.pos.x-x>0 and e.pos.x-x<42: game.test_jump = true
		if game.deaths>5:
			push_error("Parcours bloque vers "+str(game.player.position))
			quit(1)
			return
	push_error("Arrivee non atteinte")
	quit(1)
