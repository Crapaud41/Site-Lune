const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const shell=fs.readFileSync(__dirname+'/../exports/index.html','utf8');
const inline=[...shell.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)].at(-1)[1];
function run(canPlay){
 const nodes={},navigations=[];let starts=0;
 const window={CrapaudSurprise:{canPlay:()=>canPlay},fetch(){},addEventListener(){}};
 class Engine{static getMissingFeatures(){return [];}startGame(){starts++;return Promise.resolve();}}
 vm.runInNewContext(inline,{window,Engine,URL,document:{getElementById:id=>nodes[id]??(nodes[id]={classList:{add(){}},addEventListener(){},focus(){}})},sessionStorage:{getItem:()=>null},performance:{getEntriesByType:()=>[{type:'navigate'}]},location:{href:'https://example.test/Site-Lune/jeu-crapaud/index.html',assign:url=>navigations.push(url)},setTimeout(){},console});
 return {starts,navigations};
}
const mobile=run(false);assert.equal(mobile.starts,0);assert.equal(mobile.navigations[0],'https://example.test/Site-Lune/photos.html');
const desktop=run(true);assert.equal(desktop.starts,1);assert.equal(desktop.navigations.length,0);
console.log('PASS: accès direct au jeu sur téléphone renvoyé vers Photos avant le chargement du moteur');
