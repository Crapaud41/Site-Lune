extends SceneTree

var game: Node
var failures: Array[String] = []

func _initialize() -> void:
	call_deferred("_run")

func frames(count: int) -> void:
	for i in range(count): await physics_frame

func check(condition: bool, message: String) -> void:
	if condition: print("PASS: ",message)
	else:
		failures.append(message)
		push_error(message)

func _run() -> void:
	game = load("res://main.tscn").instantiate()
	root.add_child(game)
	game.test_mode = true
	game._start_game()
	await frames(35)
	check(game.player.is_on_floor(),"Le crapaud se pose sur la berge")
	game.test_direction = 1
	await frames(30)
	check(game.player.position.x > 145,"La fleche droite deplace le crapaud")
	game.test_direction = 0
	game.test_jump = true
	var floor_y: float = game.player.position.y
	await frames(16)
	check(game.player.position.y < floor_y-35,"Le saut atteint les plateformes basses")
	await frames(45)
	check(game.player.is_on_floor(),"Le crapaud retombe sur le sol")
	var enemy: Dictionary = game.enemies[0]
	game.player.position = Vector2(enemy.pos.x,255)
	game.player.velocity = Vector2(0,170)
	game.previous_feet = 265
	await frames(12)
	check(not enemy.alive and enemy.falling,"Un saut sur le putois le fait tomber hors du niveau")
	check(game.deaths==0,"Ecraser un putois ne tue pas le joueur")
	game.player.position = Vector2(2184,286)
	game.player.velocity = Vector2.ZERO
	await frames(4)
	check(game.checkpoint and game.spawn_point.x > 2100,"Le point de reprise du milieu est active")
	var other: Dictionary = game.enemies[1]
	game.player.position = Vector2(other.pos.x,289)
	game.player.velocity = Vector2.ZERO
	await frames(3)
	check(game.mode=="respawn","Toucher un putois de cote fait perdre")
	await frames(55)
	check(game.mode=="play" and game.player.position.x>2100,"La reprise se fait au milieu du niveau")
	check(not enemy.alive,"Le putois elimine ne reapparait pas apres une reprise")
	game.player.position = Vector2(865,380)
	game.player.velocity = Vector2(0,100)
	await frames(5)
	check(game.mode=="respawn","Tomber dans l'eau declenche une reprise")
	await frames(55)
	game.player.position = Vector2(180,263)
	game.player.velocity = Vector2.ZERO
	await frames(3)
	check(game.score>0,"Les lucioles sont ramassees")
	game.player.position = Vector2(4084,289)
	game.player.velocity = Vector2.ZERO
	game.score = 0
	await frames(12)
	check(game.mode=="ending","Passer sous l'arrivee lance Murphy")
	await frames(int(game.RIDE_TIME * 60) + 5)
	check(game.cat_facing==-1,"Murphy regarde a droite pendant le depart")
	var departure_x: float = game.cat_x
	await frames(25)
	check(game.cat_x>departure_x,"Murphy avance dans le sens de son regard")
	await frames(185)
	check(game.mode=="finish_menu","La promenade avec Murphy conduit au retour aux photos")
	check(game.score==0 and game.completed_in_run,"On peut finir sans toutes les lucioles et la partie est memorisee")
	game._start_game()
	check(game.mode=="already_played","Une partie terminee ne repart pas automatiquement")
	game._reset_level()
	check(game.mode=="play" and not game.completed_in_run,"Le choix Rejouer autorise une nouvelle partie")
	check(game.enemies[0].alive and game.enemies[0].pos.y==299,"Rejouer remet les putois a leur emplacement initial")
	print("RESULTAT: ","OK" if failures.is_empty() else "ECHEC", " / ",failures.size()," erreur(s)")
	quit(0 if failures.is_empty() else 1)
