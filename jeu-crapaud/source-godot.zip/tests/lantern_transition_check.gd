extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var first = load("res://main.tscn").instantiate()
	root.add_child(first)
	current_scene = first
	first.test_mode = true
	first.mode = "finish_menu"
	first._activate()
	for i in range(40): await physics_frame
	if current_scene == null or current_scene.scene_file_path != "res://lantern.tscn":
		push_error("Suivant ne conduit pas au nouveau niveau")
		quit(1)
		return
	if current_scene.mode != "intro":
		push_error("Introduction du nouveau niveau manquante")
		quit(1)
		return
	var key = InputEventKey.new()
	key.keycode = KEY_ENTER
	key.pressed = true
	current_scene._input(key)
	if current_scene.mode != "play":
		push_error("Entree ne lance pas le nouveau niveau")
		quit(1)
		return
	print("PASS: Suivant, transition, nouvelle scene et demarrage clavier")
	quit(0)
