extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var first = load("res://main.tscn").instantiate()
	root.add_child(first)
	current_scene = first
	first.test_mode = true
	first.mode = "finish_menu"
	first._activate()
	for i in range(40): await physics_frame
	if current_scene == null or current_scene.scene_file_path != "res://lantern.tscn":
		push_error("Suivant ne conduit pas au nouveau niveau")
		quit(1)
		return
	if current_scene.mode != "intro":
		push_error("Introduction du nouveau niveau manquante")
		quit(1)
		return
	var key = InputEventKey.new()
	key.keycode = KEY_ENTER
	key.pressed = true
	var start = current_scene.player.position
	current_scene.test_mode = true
	current_scene.test_direction = 1
	for i in range(30): await physics_frame
	assert(current_scene.player.position == start, "Murphy attend pendant le dialogue")
	key.keycode = KEY_RIGHT
	current_scene._input(key)
	assert(current_scene.mode == "intro" and current_scene.dialogue_index == 0)
	key.keycode = KEY_ENTER
	current_scene._input(key)
	assert(current_scene.mode == "intro" and current_scene.dialogue_index == 1, "Murphy repond au premier appui")
	key.echo = true
	current_scene._input(key)
	assert(current_scene.mode == "intro", "Une touche maintenue ne saute pas la reponse")
	key.echo = false
	current_scene._input(key)
	if current_scene.mode != "play":
		push_error("Entree ne lance pas le nouveau niveau")
		quit(1)
		return
	current_scene.test_direction = 0
	current_scene._die()
	for i in range(50): await physics_frame
	assert(current_scene.mode == "play", "Pas de dialogue apres une chute")
	current_scene._reset_level()
	assert(current_scene.mode == "play", "Rejouer reste immediat")
	print("PASS: Suivant, deux repliques, attente immobile, Entree sans repetition, reprise sans dialogue")
	quit(0)
