const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const script=fs.readFileSync(__dirname+'/../web/photo-trigger.js','utf8');
const storage=new Map(),key='au-fil-des-nuits.crapaud.completed.v1';
function page(type='navigate',device={}){
  const navigations=[],window={addEventListener(){},matchMedia:q=>({matches:q==='(pointer: coarse)'?!!device.coarse:!!device.fine})};
  const navigator={userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',platform:'Win32',maxTouchPoints:0,...device};
  vm.runInNewContext(script,{window,navigator,URL,decodeURIComponent,JSON,sessionStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},location:{href:'https://exemple.test/Site-Lune/photos.html',assign:x=>navigations.push(x)},performance:{getEntriesByType:()=>[{type}]}});
  return {api:window.CrapaudSurprise,navigations};
}
const photo='photos/nature/animaux/02%20Juillet%202026.jpg';
let p=page();assert.equal(p.api.enter('autre.jpg',{}),false);
assert.equal(p.api.enter(photo,{album:'nature',page:3}),true);assert.equal(p.navigations.length,1);
p.api.enter(photo,{});assert.equal(p.navigations.length,1);
storage.set(key,'1');p=page();assert.equal(p.api.enter(photo,{}),false);assert.equal(p.navigations.length,0);
assert.equal(p.api.nextIndex(['avant.jpg',photo,'apres.jpg'],0,1),1);
assert.equal(p.api.nextIndex(['avant.jpg',photo,'apres.jpg'],2,-1),1);
const restored=p.api.takeReturnState();assert.equal(restored.album,'nature');assert.equal(restored.page,3);
assert.equal(p.api.takeReturnState(),null);
p=page('reload');assert.equal(p.api.completed(),false);p.api.enter(photo,{});assert.equal(p.navigations.length,1);
const devices=[
 {userAgent:'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) Mobile/15E148',fine:true},
 {userAgent:'Mozilla/5.0 (Linux; Android 15; SM-S928B) Chrome/130.0.0.0 Mobile Safari/537.36',fine:true},
 {userAgentData:{mobile:true}},
 {userAgent:'Mozilla/5.0 (Macintosh; Intel Mac OS X)',platform:'MacIntel',maxTouchPoints:5,fine:true},
 {coarse:true}
];
for(const device of devices){p=page('reload',device);assert.equal(p.api.canPlay(),false);assert.equal(p.api.enter(photo,{}),false);assert.equal(p.navigations.length,0);}
p=page('reload',{coarse:true,fine:true,maxTouchPoints:10});assert.equal(p.api.canPlay(),true);assert.equal(p.api.enter(photo,{}),true);
console.log('PASS: photo accessible après fin et avec les flèches, retour album, F5, iPhone/Android/iPad, ordinateur tactile');
