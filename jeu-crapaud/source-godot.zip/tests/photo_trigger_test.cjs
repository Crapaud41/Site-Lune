const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const script=fs.readFileSync(__dirname+'/../web/photo-trigger.js','utf8');
const storage=new Map(),key='au-fil-des-nuits.crapaud.completed.v1';
function page(type='navigate'){
  const navigations=[],window={addEventListener(){}};
  vm.runInNewContext(script,{window,URL,decodeURIComponent,JSON,sessionStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},location:{href:'https://exemple.test/Site-Lune/photos.html',assign:x=>navigations.push(x)},performance:{getEntriesByType:()=>[{type}]}});
  return {api:window.CrapaudSurprise,navigations};
}
const photo='photos/nature/animaux/02%20Juillet%202026.jpg';
let p=page();assert.equal(p.api.enter('autre.jpg',{}),false);
assert.equal(p.api.enter(photo,{album:'nature',page:3}),true);assert.equal(p.navigations.length,1);
p.api.enter(photo,{});assert.equal(p.navigations.length,1);
storage.set(key,'1');p=page();p.api.enter(photo,{});assert.equal(p.navigations.length,0);
assert.equal(p.api.nextIndex(['avant.jpg',photo,'apres.jpg'],0,1),2);
assert.equal(p.api.nextIndex(['avant.jpg',photo,'apres.jpg'],2,-1),0);
const restored=p.api.takeReturnState();assert.equal(restored.album,'nature');assert.equal(restored.page,3);
assert.equal(p.api.takeReturnState(),null);
p=page('reload');assert.equal(p.api.completed(),false);p.api.enter(photo,{});assert.equal(p.navigations.length,1);
console.log('PASS: photo ordinaire, premiere entree, double clic, blocage apres fin, fleches, retour album, F5 pour rejouer');
