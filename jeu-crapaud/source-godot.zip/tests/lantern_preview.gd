extends SceneTree

func _initialize() -> void:
	call_deferred("_capture")

func _capture() -> void:
	var game = load("res://lantern.tscn").instantiate()
	root.add_child(game)
	game.test_mode = true
	game._start_game()
	game.set_physics_process(false)
	game.clock = 2.0
	for item in [["depart",0,Vector2(180,282)],["lanterne",1900,Vector2(2210,282)],["pont",2490,Vector2(2805,199)],["sortie-ponton",3735,Vector2(3925,263)],["maison",4220,Vector2(4456,207)]]:
		game.camera_x = item[1]
		game.player.position = item[2]
		game.checkpoint = true
		game.queue_redraw()
		await process_frame
		await RenderingServer.frame_post_draw
		var picture = root.get_texture().get_image()
		picture.save_png("res://lantern-"+item[0]+".png")
	quit()
