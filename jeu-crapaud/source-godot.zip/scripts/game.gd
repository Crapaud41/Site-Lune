extends Node2D

const Art = preload("res://scripts/pixel_art.gd")
const PixelFont = preload("res://scripts/pixel_font.gd")
const WORLD_END = 4400.0
const RETURN_URL = "https://crapaud41.github.io/Site-Lune/photos.html"
const PHOTO_TRIGGER = "02 Juillet 2026.jpg"
const COMPLETED_KEY = "au-fil-des-nuits.crapaud.completed.v1"
const GOLD = Color("e8c482")
const WHITE = Color("eee5d4")
const CAT_ARRIVAL_TIME = 1.8
const MURPHY_REPLY_TIME = CAT_ARRIVAL_TIME + 2.6
const MOUNT_TIME = MURPHY_REPLY_TIME + 2.6
const RIDE_TIME = MOUNT_TIME + 0.7
const FINISH_MENU_TIME = RIDE_TIME + 3.5

var mode = "title"
var clock = 0.0
var mode_time = 0.0
var camera_x = 0.0
var player: CharacterBody2D
var facing = 1
var coyote = 0.0
var jump_buffer = 0.0
var checkpoint = false
var spawn_point = Vector2(90, 286)
var deaths = 0
var platforms: Array[Dictionary] = []
var enemies: Array[Dictionary] = []
var flies: Array[Dictionary] = []
var particles: Array[Dictionary] = []
var score = 0
var collected: Dictionary = {}
var previous_feet = 0.0
var death_origin = Vector2.ZERO
var finish_time = 0.0
var cat_x = 4220.0
var cat_facing = 1
var completed_in_run = false
var ride_offset = Vector2.ZERO
var toast = ""
var toast_time = 0.0
var title_button = Rect2(217, 218, 206, 32)
var retry_button = Rect2(176, 224, 132, 28)
var exit_button = Rect2(324, 224, 140, 28)
var test_mode = false
var test_direction = 0.0
var test_jump = false

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_build_level()
	player = CharacterBody2D.new()
	player.name = "Crapaud"
	player.floor_snap_length = 4.0
	var hitbox = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = Vector2(17, 19)
	hitbox.shape = shape
	player.add_child(hitbox)
	add_child(player)
	player.position = spawn_point
	previous_feet = player.position.y + 10.0
	if OS.has_feature("web"):
		mode = "web_wait"
		completed_in_run = bool(JavaScriptBridge.eval("(() => { try { return sessionStorage.getItem('" + COMPLETED_KEY + "') === '1'; } catch(e) { return false; } })()"))
		if completed_in_run: mode = "already_played"
	if OS.get_cmdline_user_args().has("--play"):
		_start_game()
	queue_redraw()

func _platform(x: float, y: float, w: float, h: float, kind: String) -> void:
	var rect = Rect2(x, y, w, h)
	platforms.append({"rect":rect,"kind":kind})
	var body = StaticBody2D.new()
	var collision = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = rect.size
	collision.shape = shape
	collision.position = rect.get_center()
	collision.one_way_collision = kind == "lily"
	collision.one_way_collision_margin = 5.0
	body.add_child(collision)
	add_child(body)

func _enemy(x: float, left: float, right: float) -> void:
	enemies.append({"pos":Vector2(x, 299),"home":Vector2(x,299),"left":left,"right":right,"dir":-1,"alive":true,"falling":false,"vy":-105.0,"spin":0.0})

func _build_level() -> void:
	for segment in [[0,700],[900,1510],[1710,2460],[2660,3380],[3580,4520]]:
		_platform(segment[0], 300, segment[1]-segment[0], 100, "earth")
	for p in [[744,279,112],[1554,278,112],[2504,279,112],[3424,278,112], [330,259,64],[425,221,68],[530,259,64], [1120,252,64],[1220,215,64],[1320,252,64], [1890,255,68],[1990,218,68],[2090,255,68], [2860,255,70],[2960,219,70],[3070,255,70]]:
		_platform(p[0],p[1],p[2],8,"lily")
	for stump in [[1030,275,30,25],[2290,278,32,22],[3240,274,32,26]]:
		_platform(stump[0],stump[1],stump[2],stump[3],"stump")
	_enemy(610,560,665)
	_enemy(1440,1380,1480)
	_enemy(2360,2340,2420)
	_enemy(3320,3290,3350)
	_enemy(3880,3820,3940)
	for x in range(180,4200,115):
		var y = 263.0
		for platform in platforms:
			var r: Rect2 = platform.rect
			if platform.kind == "lily" and x > r.position.x - 8 and x < r.end.x + 8:
				y = r.position.y - 25
		flies.append({"pos":Vector2(x,y),"id":flies.size()})
	for point in [Vector2(460,190),Vector2(1252,183),Vector2(2024,187),Vector2(2990,188)]:
		flies.append({"pos":point,"id":flies.size()})

func _start_game() -> void:
	if completed_in_run:
		mode = "already_played"
		return
	mode = "play"
	mode_time = 0.0
	player.position = spawn_point
	player.velocity = Vector2.ZERO
	toast = "LE MARAIS VOUS ATTEND"
	toast_time = 2.0

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE:
			if mode == "play": mode = "pause"
			elif mode == "pause": mode = "play"
		if event.keycode == KEY_UP:
			jump_buffer = .13
		if event.keycode == KEY_ENTER or event.keycode == KEY_SPACE:
			_activate()
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		var p = get_global_mouse_position()
		if mode == "finish_menu":
			if retry_button.has_point(p): _reset_level()
			elif exit_button.has_point(p): _return_to_photos()
		elif mode == "already_played" and title_button.has_point(p):
			_return_to_photos()
		elif title_button.has_point(p):
			_activate()

func _activate() -> void:
	if mode == "title":
		mode = "broken"
		mode_time = 0.0
	elif mode == "broken" and mode_time > 1.0:
		mode = "eat_button"
		mode_time = 0.0
	elif mode == "pause": mode = "play"
	elif mode == "finish_menu": _return_to_photos()
	elif mode == "already_played": _return_to_photos()

func _mark_completed() -> void:
	completed_in_run = true
	if OS.has_feature("web") and not test_mode:
		JavaScriptBridge.eval("try { sessionStorage.setItem('" + COMPLETED_KEY + "','1'); } catch(e) {}")

func _return_to_photos() -> void:
	if test_mode: return
	if OS.has_feature("web"):
		JavaScriptBridge.eval("window.CrapaudPage.returnToPhotos();")
	else:
		OS.shell_open(RETURN_URL)

func _reset_level() -> void:
	completed_in_run = false
	if OS.has_feature("web") and not test_mode:
		JavaScriptBridge.eval("try { sessionStorage.removeItem('" + COMPLETED_KEY + "'); } catch(e) {}")
	checkpoint = false
	spawn_point = Vector2(90,286)
	score = 0
	collected.clear()
	deaths = 0
	for enemy in enemies:
		enemy.alive = true
		enemy.falling = false
		enemy.vy = -105.0
		enemy.pos = enemy.home
		enemy.spin = 0.0
		enemy.dir = -1
	cat_x = 4220.0
	cat_facing = 1
	camera_x = 0.0
	_start_game()

func _die() -> void:
	if mode != "play": return
	deaths += 1
	death_origin = player.position
	mode = "respawn"
	mode_time = 0.0
	_burst(player.position, Color("b8d9b6"), 12)

func _burst(at: Vector2, color: Color, count: int) -> void:
	for i in range(count):
		var angle = float(i) / count * TAU
		particles.append({"pos":at,"vel":Vector2(cos(angle),sin(angle))*randf_range(25,70),"life":.65,"color":color})

func _physics_process(delta: float) -> void:
	if mode == "web_wait" and OS.has_feature("web"):
		if bool(JavaScriptBridge.eval("window.__crapaudStartRequested === true")):
			mode = "eat_button"
			mode_time = 0.0
			JavaScriptBridge.eval("window.CrapaudPage.showGame();")
	clock += delta
	mode_time += delta
	toast_time = maxf(0, toast_time-delta)
	for i in range(particles.size()-1,-1,-1):
		particles[i].life -= delta
		particles[i].pos += particles[i].vel * delta
		particles[i].vel.y += 100 * delta
		if particles[i].life <= 0: particles.remove_at(i)
	if mode == "eat_button" and mode_time > 2.2:
		_start_game()
	elif mode == "respawn" and mode_time > .75:
		player.position = spawn_point
		player.velocity = Vector2.ZERO
		previous_feet = player.position.y + 10
		mode = "play"
		jump_buffer = 0.0
		coyote = 0.0
	elif mode == "play":
		_update_player(delta)
		_update_enemies(delta)
		for fly in flies:
			if not collected.has(fly.id) and player.position.distance_to(fly.pos) < 22:
				collected[fly.id] = true
				score += 1
				_burst(fly.pos,GOLD,5)
		if not checkpoint and player.position.x >= 2180:
			checkpoint = true
			spawn_point = Vector2(2205,286)
			toast = "POINT DE REPRISE ACTIVE"
			toast_time = 3.0
			_burst(Vector2(2205,265),GOLD,14)
		if player.position.y > 385: _die()
		if player.position.x >= 4080 and player.is_on_floor():
			mode = "ending"
			mode_time = 0
			finish_time = clock
			player.velocity = Vector2.ZERO
		camera_x = clampf(lerpf(camera_x, player.position.x-215, minf(1,delta*7)),0,WORLD_END-640)
	elif mode == "ending":
		if mode_time < CAT_ARRIVAL_TIME:
			cat_facing = 1
			cat_x = move_toward(cat_x, player.position.x + 23, delta*74)
		elif mode_time >= MOUNT_TIME and mode_time < RIDE_TIME:
			cat_facing = -1
			var t = clampf((mode_time-MOUNT_TIME)/(RIDE_TIME-MOUNT_TIME),0,1)
			player.position = Vector2(4080,289).lerp(Vector2(cat_x-8,263),t) + Vector2(0,-sin(t*PI)*24)
		elif mode_time >= RIDE_TIME and mode_time < FINISH_MENU_TIME:
			cat_facing = -1
			cat_x += delta*92
			player.position = Vector2(cat_x-8,263+sin(clock*12))
		elif mode_time >= FINISH_MENU_TIME:
			_mark_completed()
			mode = "finish_menu"
			mode_time = 0
		camera_x = move_toward(camera_x,WORLD_END-640,delta*75)
	_update_falling_enemies(delta)
	queue_redraw()

func _update_player(delta: float) -> void:
	var direction = test_direction if test_mode else float(Input.is_key_pressed(KEY_RIGHT))-float(Input.is_key_pressed(KEY_LEFT))
	jump_buffer = maxf(0,jump_buffer-delta)
	if test_mode and test_jump:
		jump_buffer = .13
		test_jump = false
	coyote = .10 if player.is_on_floor() else maxf(0,coyote-delta)
	player.velocity.x = move_toward(player.velocity.x,direction*155,1250*delta)
	if direction: facing = 1 if direction > 0 else -1
	player.velocity.y = minf(510,player.velocity.y + 1000*delta)
	if jump_buffer > 0 and coyote > 0:
		player.velocity.y = -355
		jump_buffer = 0
		coyote = 0
		_burst(player.position+Vector2(0,10),Color("68884f"),4)
	if not test_mode and not Input.is_key_pressed(KEY_UP) and player.velocity.y < -175:
		player.velocity.y = -175
	previous_feet = player.position.y + 10
	player.move_and_slide()
	player.position.x = clampf(player.position.x,12,WORLD_END-12)

func _update_enemies(delta: float) -> void:
	for enemy in enemies:
		if not enemy.alive: continue
		enemy.pos.x += enemy.dir*22*delta
		if enemy.pos.x < enemy.left: enemy.dir = 1
		if enemy.pos.x > enemy.right: enemy.dir = -1
		var rect = Rect2(enemy.pos-Vector2(11,20),Vector2(24,20))
		if Rect2(player.position-Vector2(8,9),Vector2(16,19)).intersects(rect):
			if player.velocity.y > 35 and previous_feet <= rect.position.y+8:
				enemy.alive = false
				enemy.falling = true
				enemy.vy = -100.0
				player.velocity.y = -235
				_burst(enemy.pos-Vector2(0,15),GOLD,9)
			else:
				_die()
				return

func _update_falling_enemies(delta: float) -> void:
	for enemy in enemies:
		if enemy.falling:
			enemy.vy += 500*delta
			enemy.pos.y += enemy.vy*delta
			enemy.pos.x += 25*delta
			enemy.spin += delta*5
			if enemy.pos.y > 420: enemy.falling = false

func _rect(x: float,y: float,w: float,h: float,c: Color) -> void:
	draw_rect(Rect2(floorf(x),floorf(y),w,h),c)

func _text(text: String, at: Vector2, c: Color=WHITE, scale: int=1, centered: bool=false) -> void:
	if centered: at.x -= PixelFont.width(text,scale)/2.0
	PixelFont.paint(self,text,at,c,scale)

func _button(rect: Rect2,text: String) -> void:
	var hover = rect.has_point(get_global_mouse_position())
	_rect(rect.position.x+2,rect.position.y+3,rect.size.x,rect.size.y,Color("070d1b"))
	draw_rect(rect,Color("344e4d") if hover else Color("24313f"))
	draw_rect(rect, GOLD if hover else Color("69746a"),false,1)
	_text(text,rect.get_center()-Vector2(0,3),GOLD,1,true)

func _sprite(kind: String, at: Vector2, dir: int=1, scale: int=1, moving: bool=false, rotation: float=0) -> void:
	var pixels: Array = Art.sprite(kind)
	var palette = Art.palette(kind)
	var width: int = pixels[0].length()
	var height = pixels.size()
	var bob = floorf(sin(clock*16)*1.2) if moving else 0.0
	for y in range(height):
		var row: String = pixels[y]
		for x in range(row.length()):
			var symbol = row[x]
			if not palette.has(symbol): continue
			var px = x if dir > 0 else width-1-x
			var point = Vector2((px-width/2.0)*scale,(y-height)*scale+bob)
			if moving and y > height-4:
				point.x += floorf(sin(clock*16 + (0 if x < width/2 else PI))*1.5)*scale
			if rotation: point = point.rotated(rotation)
			draw_rect(Rect2((at+point).floor(),Vector2(scale,scale)),palette[symbol])

func _background() -> void:
	for stripe in range(90):
		var t = stripe/89.0
		_rect(0,stripe*4,640,4,Color("10152e").lerp(Color("34454e"),t))
	for i in range(75):
		var x = fposmod(i*117.13-camera_x*.06,640)
		var y = fposmod(i*i*5.73,167)
		var bright = .35+.35*sin(clock*.7+i)
		_rect(x,y,1 if i%5 else 2,1 if i%5 else 2,Color(0.87,0.85,0.7,bright))
	var moon = Vector2(502-camera_x*.018,66)
	for y in range(-19,20):
		for x in range(-19,20):
			if x*x+y*y <= 19*19:
				var shade = Color("d9d9b2") if (x*x*13+y*7+91)%23 > 2 else Color("b6bd9a")
				_rect(moon.x+x,moon.y+y,1,1,shade)
	for layer in range(3):
		var factor = .12+layer*.13
		var c = [Color("223744"),Color("1b313a"),Color("172b31")][layer]
		for i in range(15):
			var x = fposmod(i*71-camera_x*factor,760)-60
			var top = 150+layer*26+sin(i*2.7)*23
			_rect(x,top,6+layer*2,190,c)
			_rect(x-19,top-4,44,14,c)
			_rect(x-12,top-18,32,17,c)
			_rect(x-4,top-27,17,10,c)
	_rect(0,309,640,51,Color("142c36"))
	for i in range(60):
		var x = fposmod(i*37.3-camera_x*.7,640)
		var y = 316+(i%7)*6
		_rect(x+sin(clock*.7+i)*3,y,8+i%17,1,Color("315356"))
	for i in range(16):
		var x = fposmod(i*71-camera_x*.25+clock*2,720)-40
		_rect(x,222+i%3*21,82,3,Color(.55,.67,.65,.04))

func _draw_ground(r: Rect2) -> void:
	_rect(r.position.x,r.position.y,r.size.x,r.size.y,Color("26352e"))
	_rect(r.position.x,r.position.y+9,r.size.x,8,Color("394432"))
	for x in range(int(r.position.x),int(r.end.x),8):
		if x < camera_x-24 or x > camera_x+664: continue
		_rect(x,300,8,4,Color("63744b") if x%24 else Color("7e8853"))
		var height = 5+posmod(x*7,11)
		_rect(x+1,300-height,2,height,Color("57764b"))
		_rect(x+4,302-height/2.0,2,height/2.0,Color("788b58"))
		if x%24 == 0:
			_rect(x+2,324+posmod(x,15),3,2,Color("465044"))
			_rect(x+5,348,2,3,Color("151f25"))

func _world() -> void:
	draw_set_transform(Vector2(-floorf(camera_x),0))
	for p in platforms:
		var r: Rect2 = p.rect
		if r.end.x < camera_x-30 or r.position.x > camera_x+670: continue
		if p.kind == "earth": _draw_ground(r)
		elif p.kind == "lily":
			_rect(r.get_center().x-2,r.position.y+6,3,330-r.position.y,Color("35594a"))
			_rect(r.position.x+12,r.position.y-3,r.size.x-24,3,Color("758a52"))
			_rect(r.position.x+4,r.position.y,r.size.x-8,3,Color("758a52"))
			_rect(r.position.x,r.position.y+2,r.size.x,4,Color("446a46"))
			_rect(r.position.x+6,r.position.y+6,r.size.x-12,3,Color("294b3c"))
			_rect(r.position.x+3,r.position.y,7,2,Color("182f35"))
			_rect(r.get_center().x-1,r.position.y-1,3,6,Color("b0ac6c"))
		else:
			_rect(r.position.x,r.position.y,r.size.x,r.size.y,Color("4c4038"))
			_rect(r.position.x+3,r.position.y,r.size.x-6,4,Color("9d8560"))
			_rect(r.position.x+7,r.position.y+4,3,r.size.y-4,Color("776049"))
			_rect(r.end.x-7,r.position.y+5,2,r.size.y-5,Color("302e2c"))
	for i in range(65):
		var x = i*69+24.0
		if x < camera_x-30 or x > camera_x+670: continue
		if not _solid_ground(x): continue
		var h = 18+posmod(i*13,22)
		_rect(x,300-h,2,h,Color("547055"))
		_rect(x-2,300-h-7,6,9,Color("8f7957"))
		_rect(x+6,300-h/2.0,2,h/2.0,Color("6b8159"))
	for fly in flies:
		if collected.has(fly.id): continue
		var p: Vector2 = fly.pos+Vector2(0,sin(clock*2+fly.id)*3)
		if absf(p.x-camera_x-320)>350: continue
		_rect(p.x-5,p.y-5,11,11,Color(.91,.8,.4,.07))
		_rect(p.x-2,p.y-2,5,5,Color("b69e56"))
		_rect(p.x-1,p.y-1,3,3,Color("ffe5a0"))
		_rect(p.x-4,p.y-1,2,1,Color("a2bb9a"))
		_rect(p.x+3,p.y-1,2,1,Color("a2bb9a"))
	_rect(2199,248,4,52,Color("8a755c"))
	_rect(2191,244,20,18,Color("243b35"))
	_rect(2195,248,12,10,GOLD if checkpoint else Color("8b9860"))
	if checkpoint: _rect(2197,250,8,6,Color("ffe6a8"))
	for pole in [4050,4140]:
		_rect(pole,231,4,69,Color("a39173"))
		_rect(pole-1,229,6,3,GOLD)
	_rect(4054,233,86,22,Color("e9e0c5"))
	for i in range(11):
		for j in range(2):
			if (i+j)%2==0:_rect(4054+i*8,233+j*4,8,4,Color("27323b"))
	_text("ARRIVEE",Vector2(4074,245),Color("24313b"),1)
	for enemy in enemies:
		if enemy.alive or enemy.falling:
			_sprite("skunk",enemy.pos,enemy.dir,1,enemy.alive,enemy.spin if enemy.falling else 0)
	if mode in ["ending","finish_menu"]:
		var cat_moving = mode == "ending" and (mode_time < CAT_ARRIVAL_TIME or mode_time >= RIDE_TIME)
		_sprite("cat",Vector2(cat_x,300),cat_facing,2,cat_moving)
	if mode != "respawn":
		var jumping = mode=="play" and not player.is_on_floor()
		var visual = player.position+Vector2(0,12)
		_sprite("toad",visual,facing,1,absf(player.velocity.x)>20 and not jumping)
	for p in particles:
		var c: Color = p.color
		c.a = clampf(p.life/.4,0,1)
		_rect(p.pos.x,p.pos.y,2,2,c)
	draw_set_transform(Vector2.ZERO)

func _solid_ground(x: float) -> bool:
	for p in platforms:
		var r: Rect2 = p.rect
		if p.kind=="earth" and x>=r.position.x and x<r.end.x:return true
	return false

func _draw_ending_dialogue() -> void:
	if mode_time < CAT_ARRIVAL_TIME or mode_time >= MOUNT_TIME:
		return
	var is_reply = mode_time >= MURPHY_REPLY_TIME
	var speaker_x = (cat_x if is_reply else player.position.x) - camera_x
	var center_x = clampf(speaker_x + (52.0 if is_reply else -52.0), 144.0, 496.0)
	var accent = GOLD if is_reply else Color("a5c47c")
	var box = Rect2(center_x - 132, 166, 264, 47)
	_rect(box.position.x + 2, box.position.y + 3, box.size.x, box.size.y, Color("070d1b"))
	draw_rect(box, Color("182630"))
	draw_rect(box, accent, false, 1)
	draw_colored_polygon(PackedVector2Array([
		Vector2(speaker_x - 6, box.end.y - 1),
		Vector2(speaker_x + 6, box.end.y - 1),
		Vector2(speaker_x, box.end.y + 7)
	]), accent)
	_text("MURPHY" if is_reply else "CRAPAUD", Vector2(center_x, 173), accent, 1, true)
	if is_reply:
		_text("JE SUIS VENU TE CHERCHER.", Vector2(center_x, 183), WHITE, 2, true)
		_text("TU T’ES PERDU EN CHEMIN.", Vector2(center_x, 197), WHITE, 2, true)
	else:
		_text("MAIS QU’EST-CE QUE TU FAIS", Vector2(center_x, 183), WHITE, 2, true)
		_text("LÀ, MURPHY ?", Vector2(center_x, 197), WHITE, 2, true)

func _draw() -> void:
	if mode == "web_wait":
		_rect(0,0,640,360,Color("070a13"))
		return
	_background()
	if mode in ["broken","eat_button"]:
		_rect(0,0,640,360,Color("070a13"))
		if mode_time > 1 or mode=="eat_button":
			_text("OUPS...",Vector2(320,110),GOLD,4,true)
			_text("JE CROIS QUE TU AS CASSE LE SITE.",Vector2(320,157),WHITE,2,true)
			if mode=="broken":_button(title_button,"RETOURNER SUR LE SITE")
		if mode=="eat_button":
			var t = clampf(mode_time/.6,0,1)
			_sprite("toad",Vector2(490,295),-1,3)
			if mode_time < .8:
				_rect(410-t*160,244,160*t,3,Color("bb7e88"))
				var button = Rect2(title_button.position.lerp(Vector2(460,245),t),title_button.size*(1-t*.8))
				draw_rect(button,Color("344e4d"))
			if mode_time > .8:
				_text("IL VIENT DE MANGER LA SORTIE.",Vector2(320,210),GOLD,2,true)
				_text("RATTRAPE-LE !",Vector2(320,239),WHITE,2,true)
		return
	_world()
	if mode == "ending":
		_draw_ending_dialogue()
	if mode=="title":
		_rect(0,0,640,360,Color(0.02,0.04,0.09,.65))
		_text("AU FIL DES NUITS",Vector2(320,68),GOLD,1,true)
		_text("LE DETOUR",Vector2(320,102),WHITE,5,true)
		_text("DU CRAPAUD",Vector2(320,139),GOLD,4,true)
		_text("UNE PETITE ESCAPADE AU CLAIR DE LUNE",Vector2(320,184),WHITE,1,true)
		_button(title_button,"COMMENCER  >")
		_text("FLECHES GAUCHE / DROITE : MARCHER",Vector2(320,279),WHITE,1,true)
		_text("FLECHE DU HAUT : SAUTER   -   ECHAP : PAUSE",Vector2(320,294),WHITE,1,true)
		_text("PROTOTYPE JOUABLE - UN SEUL NIVEAU",Vector2(320,330),Color("8baba4"),1,true)
	elif mode == "already_played":
		_rect(0,0,640,360,Color(.02,.04,.08,.85))
		_text("LE CRAPAUD SE REPOSE",Vector2(320,135),GOLD,2,true)
		_text("ACTUALISE LA PAGE AVEC F5 POUR REJOUER.",Vector2(320,177),WHITE,1,true)
		_button(title_button,"RETOURNER AUX PHOTOS")
	else:
		_rect(10,10,166,25,Color(.03,.06,.11,.8))
		_text("LUCIOLES  %02d / %02d"%[score,flies.size()],Vector2(21,20),GOLD,1)
		_text("REPRISE : "+("ACTIVE" if checkpoint else "A TROUVER"),Vector2(20,43),WHITE,1)
		if toast_time > 0 and mode=="play":
			_rect(170,65,300,24,Color(.03,.06,.11,.85))
			_text(toast,Vector2(320,74),GOLD,1,true)
		if player.position.x < 350 and mode=="play":
			_text("< > MARCHER     HAUT : SAUTER",Vector2(320,337),WHITE,1,true)
		if mode=="respawn":
			_rect(0,0,640,360,Color(.04,.08,.12,.25))
			_text("ON REPREND TRANQUILLEMENT...",Vector2(320,148),WHITE,2,true)
		if mode=="pause":
			_rect(0,0,640,360,Color(.02,.04,.08,.75))
			_text("PETITE PAUSE",Vector2(320,142),GOLD,3,true)
			_button(title_button,"REPRENDRE")
		if mode=="finish_menu":
			_rect(0,0,640,360,Color(.02,.04,.08,.8))
			_text("BIEN RENTRES !",Vector2(320,102),GOLD,3,true)
			_text("BON... ON N'A RIEN CASSE FINALEMENT.",Vector2(320,145),WHITE,1,true)
			_text("%d LUCIOLES RAMASSEES"%score,Vector2(320,174),GOLD,2,true)
			_text("MURPHY CONNAISSAIT LE CHEMIN.",Vector2(320,196),WHITE,1,true)
			_button(retry_button,"REJOUER")
			_button(exit_button,"TERMINER LA PARTIE")

