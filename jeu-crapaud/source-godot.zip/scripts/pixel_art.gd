extends RefCounted

const TOAD = [
"....................",
".....GGG....GGG.....",
"....GEEEG..GEEEG....",
"....GEKEGGGGEKEG....",
"...GGGGGGGGGGGGGG...",
"..GgggGGGGGGGggggG..",
".GgggGgggGggggGgggG.",
".GggggggggggggggggG.",
".GgGggGggggggGggGgG.",
"..GggggSSSSSSggggG..",
"...GGgSSSSSSSSgGG...",
"..GGGGSSSSSSSSGGGG..",
".GGGGG.GGGGGG.GGGGG.",
".GGG............GGG.",
"....................",
"...................."]

const SKUNK = [
"..WWW...................",
".WKKKW..................",
"WKKKKKW.................",
"WKKWKKW.................",
".WKWKKW.....KKK....KKK...",
"..WKKKKKWWWWKKKKKKKKKK..",
"...KKKKWWWWWWKKKKKKEKKK.",
"....KKWWWWWWWWKKKKKKKKKK",
"....KKKKKKKKKKKKKKKKKKK.",
"....KKKKKKKKKKKKKKKKK...",
".....KKKKKKKKKKKKKKK....",
".....KKK..KKKK..KKK.....",
".....KK....KK....KK.....",
"....KKK...KKK...KKK....."]

const CAT = [
".........K........K.................",
"........KKK......KKK................",
"........KPKK....KKPK................",
"........KKKKKKKKKKKK................",
".......KKKKKKKKKKKKKK...............",
".......KKEKKKKKKEKKKK...............",
".......KKKKKKPKKKKKKK...............",
"........KKKKKKKKKKKK................",
".......KKKKKKKKKKKKKKKKKKKKKKK......",
"......KKKKKKKKKKKKKKKKKKKKKKKKKK....",
"......KKKKKKKKKKKKKKKKKKKKKKKKKKKK..",
".......KKKKKKKKKKKKKKKKKKKKKKKKKKKK.",
"........KKKKKKKKKKKKKKKKKKKKKKK..KK.",
".........KKKKKKKKKKKKKKKKKKKKKK...KK",
"..........KKKKKKKKKKKKKKKKKKKK....KK",
"..........KKKKKKKKKKKKKKKKKKK.....KK",
"..........KKKKKKKKKKKKKKKKKK.....KK.",
"...........KKK...KKK...KKK.....KKK..",
"...........KK....KK....KKKKKKKKK....",
"..........KKK...KKK...KKK..........."]

static func palette(kind: String) -> Dictionary:
	if kind == "toad":
		return {"G":Color("68884f"),"g":Color("435e3b"),"S":Color("b4bb78"),"E":Color("e8c67d"),"K":Color("202d29")}
	if kind == "skunk":
		return {"K":Color("29273c"),"W":Color("e5dfd1"),"E":Color("e7c176")}
	return {"K":Color("322c40"),"P":Color("756072"),"E":Color("d8d58b")}

static func sprite(kind: String) -> Array:
	if kind == "toad": return TOAD
	if kind == "skunk": return SKUNK
	return CAT
