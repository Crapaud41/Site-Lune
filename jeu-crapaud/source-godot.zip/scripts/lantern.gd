extends "res://scripts/game.gd"

# Independent level. The garden prototype is intentionally kept in its own scene.
const LENGTH = 4860.0
const START = Vector2(130, 282)
const REST = Vector2(2210, 282)
const WINDOW = Rect2(4594, 171, 42, 51)
const WATER = Color("173b48")
const MOSS = Color("76916b")
const RIDER_OFFSET = Vector2(-7, -10)
const STEP = Rect2(4447, 224, 18, 18)
var murphy_pixels: Array[String] = []
var entry_origin = Vector2.ZERO
var tongue_time = 0.0
var tongue_tip = Vector2.ZERO

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	# Extend the torso only. The head, fur height and paws keep their proportions.
	for y in range(Art.CAT.size()):
		var row: String = Art.CAT[y]
		murphy_pixels.append(row.left(22) + (row[22] if y < 17 else ".").repeat(8) + row.substr(22))
	_build_level()
	player = CharacterBody2D.new()
	player.name = "MurphyEtCrapaud"
	player.floor_snap_length = 5.0
	var shape = RectangleShape2D.new()
	shape.size = Vector2(28, 26)
	var collision = CollisionShape2D.new()
	collision.shape = shape
	collision.position = Vector2(0,4)
	player.add_child(collision)
	add_child(player)
	spawn_point = START
	player.position = START
	facing = 1
	mode = "intro"
	retry_button = Rect2(151, 248, 144, 30)
	exit_button = Rect2(311, 248, 178, 30)
	if OS.get_cmdline_user_args().has("--play"):
		_start_game()

func _build_level() -> void:
	for r in [[0,600],[1000,1580],[1940,2520],[3080,3750],[4050,4860]]:
		_platform(r[0], 300, r[1]-r[0], 90, "earth")
	# Broken boardwalk. Each gap teaches a little more height and distance.
	for p in [[620,282,90],[750,258,88],[875,280,90],[3510,267,100],[3650,236,80],[3760,267,82],[3880,280,85]]:
		_platform(p[0],p[1],p[2],8,"board")
	# Optional high route on the bank, then three broad lily pads.
	for p in [[1190,269,40,31],[1300,240,64,60],[1420,230,70,70],[3180,274,34,26]]:
		_platform(p[0],p[1],p[2],p[3],"stone")
	for p in [[1610,277,72],[1720,256,76],[1835,278,75]]:
		_platform(p[0],p[1],p[2],8,"lily")
	# Remains of a small stone bridge, rising then falling over the water.
	for p in [[2540,270,70],[2650,239,76],[2765,216,80],[2890,240,72],[3000,271,65]]:
		_platform(p[0],p[1],p[2],8,"pier")
	# The light gives the final ascent a visible destination.
	for p in [[4250,271,64,29],[4350,240,72,60]]:
		_platform(p[0],p[1],p[2],p[3],"stone")
	_platform(STEP.position.x,STEP.position.y,STEP.size.x,STEP.size.y,"step")
	_platform(4570,222,84,10,"sill")
	_enemy(480,440,525)
	_enemy(2440,2390,2480)
	_enemy(3370,3310,3430)
	for p in [[310,263],[666,249],[794,225],[920,247],[1210,235],[1332,206],[1455,196],[1646,243],[1758,222],[1872,244],[2110,264],[2390,257],[2575,236],[2688,205],[2805,182],[2926,206],[3032,237],[3560,233],[3922,246],[4456,190]]:
		flies.append({"pos":Vector2(p[0],p[1]),"id":flies.size()})

func _movement_end() -> float:
	return LENGTH

func _platform(x: float, y: float, w: float, h: float, kind: String) -> void:
	var rect = Rect2(x,y,w,338-y if kind=="pier" else h)
	platforms.append({"rect":rect,"kind":kind})
	var body = StaticBody2D.new()
	var collision = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = rect.size
	collision.shape = shape
	collision.position = rect.get_center()
	collision.one_way_collision = kind in ["board","lily","sill"]
	collision.one_way_collision_margin = 5.0
	body.add_child(collision)
	add_child(body)

func _start_game() -> void:
	mode = "play"
	mode_time = 0
	player.position = spawn_point
	player.velocity = Vector2.ZERO

func _reset_level() -> void:
	checkpoint = false
	spawn_point = START
	score = 0
	deaths = 0
	collected.clear()
	particles.clear()
	completed_in_run = false
	flight_enabled = false
	secret_digits = ""
	camera_x = 0
	clock = 0
	tongue_time = 0
	jump_buffer = 0
	coyote = 0
	for e in enemies:
		e.alive = true
		e.falling = false
		e.pos = e.home
		e.dir = -1
		e.vy = -105.0
		e.spin = 0.0
	_start_game()

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if mode == "intro" and event.keycode in [KEY_ENTER,KEY_SPACE,KEY_RIGHT,KEY_UP]:
			_start_game()
			return
		if mode == "finish_menu" and event.keycode == KEY_ENTER:
			_reset_level()
			return
		if mode == "play":
			if event.keycode == KEY_END and flight_enabled:
				player.position = Vector2(4380,220)
				player.velocity = Vector2.ZERO
				flight_enabled = false
				secret_digits = ""
				return
			if _handle_flight_key(event): return
			if event.keycode == KEY_UP: jump_buffer = .14
			if event.keycode == KEY_SPACE: _tongue()
		if event.keycode == KEY_ESCAPE:
			if mode == "play": mode = "pause"
			elif mode == "pause": mode = "play"
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		var point = get_global_mouse_position()
		if mode == "intro": _start_game()
		elif mode == "pause" and title_button.has_point(point): mode = "play"
		elif mode == "finish_menu":
			if retry_button.has_point(point): _reset_level()
			elif exit_button.has_point(point): _return_to_photos()

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and mode == "play":
		mode = "pause"

func _tongue() -> void:
	if tongue_time > 0: return
	tongue_time = .22
	var mouth = player.position + Vector2(RIDER_OFFSET.x*facing, RIDER_OFFSET.y + 6)
	tongue_tip = mouth + Vector2(facing*56,-7)
	var nearest = 72.0
	for fly in flies:
		var d: Vector2 = fly.pos - mouth
		if not collected.has(fly.id) and d.x*facing > -8 and d.length() < nearest:
			nearest = d.length()
			tongue_tip = fly.pos
	for fly in flies:
		if not collected.has(fly.id) and fly.pos.distance_to(tongue_tip) < 2:
			_collect(fly)

func _collect(fly: Dictionary) -> void:
	collected[fly.id] = true
	score += 1
	_burst(fly.pos,GOLD,6)

func _move(delta: float) -> void:
	var direction = test_direction if test_mode else float(Input.is_key_pressed(KEY_RIGHT))-float(Input.is_key_pressed(KEY_LEFT))
	jump_buffer = maxf(0,jump_buffer-delta)
	if test_mode and test_jump:
		jump_buffer = .14
		test_jump = false
	coyote = .10 if player.is_on_floor() else maxf(0,coyote-delta)
	player.velocity.x = move_toward(player.velocity.x,direction*155,1150*delta)
	if direction: facing = 1 if direction > 0 else -1
	player.velocity.y = minf(510,player.velocity.y+1000*delta)
	if coyote > 0 and jump_buffer > 0:
		player.velocity.y = -380
		jump_buffer = 0
		coyote = 0
		_burst(player.position+Vector2(0,16),MOSS,4)
	if not test_mode and not Input.is_key_pressed(KEY_UP) and player.velocity.y < -185:
		player.velocity.y = -185
	previous_feet = player.position.y+17
	player.move_and_slide()
	player.position.x = clampf(player.position.x,18,LENGTH-18)

func _hazards(delta: float) -> void:
	for e in enemies:
		if not e.alive: continue
		e.pos.x += e.dir*24*delta
		if e.pos.x < e.left: e.dir = 1
		if e.pos.x > e.right: e.dir = -1
		var r = Rect2(e.pos-Vector2(11,18),Vector2(24,18))
		if Rect2(player.position-Vector2(13,9),Vector2(26,26)).intersects(r):
			if player.velocity.y > 25 and previous_feet <= r.position.y+8:
				e.alive = false
				e.falling = true
				e.vy = -100.0
				player.velocity.y = -260
				_burst(e.pos,GOLD,8)
			else:
				_die()
				return
	if not _solid_ground(player.position.x) and player.position.y+17 > 322:
		_die()

func _physics_process(delta: float) -> void:
	if mode == "pause":
		queue_redraw()
		return
	clock += delta
	mode_time += delta
	toast_time = maxf(0,toast_time-delta)
	tongue_time = maxf(0,tongue_time-delta)
	for i in range(particles.size()-1,-1,-1):
		particles[i].life -= delta
		particles[i].pos += particles[i].vel*delta
		particles[i].vel.y += 100*delta
		if particles[i].life <= 0: particles.remove_at(i)
	if mode == "play":
		if flight_enabled:
			_update_flight(delta)
			if player.velocity.x != 0: facing = int(signf(player.velocity.x))
			var direction = float(Input.is_key_pressed(KEY_RIGHT))-float(Input.is_key_pressed(KEY_LEFT))
			if direction: facing = int(direction)
		else:
			_move(delta)
			_hazards(delta)
		if mode == "play":
			for fly in flies:
				if not collected.has(fly.id) and player.position.distance_to(fly.pos) < 26: _collect(fly)
			if not checkpoint and player.position.x >= REST.x and player.position.x < REST.x+70 and player.is_on_floor():
				checkpoint = true
				spawn_point = REST
				toast = "LA LANTERNE GARDE VOTRE PLACE"
				toast_time = 2.7
				_burst(REST+Vector2(0,-35),GOLD,16)
			if not flight_enabled and WINDOW.has_point(player.position) and player.velocity.y >= 0:
				mode = "home"
				mode_time = 0
				entry_origin = player.position
				player.velocity = Vector2.ZERO
		camera_x = clampf(lerpf(camera_x,player.position.x-210,minf(1,delta*6)),0,LENGTH-640)
	elif mode == "respawn" and mode_time > .65:
		player.position = spawn_point
		player.velocity = Vector2.ZERO
		jump_buffer = 0
		coyote = 0
		tongue_time = 0
		camera_x = clampf(spawn_point.x-210,0,LENGTH-640)
		mode = "play"
		mode_time = 0
	elif mode == "home":
		player.position = entry_origin.lerp(Vector2(4615,205),smoothstep(0,1,mode_time/1.2))
		if mode_time > 3.2:
			_mark_completed()
			mode = "finish_menu"
			mode_time = 0
	_update_falling_enemies(delta)
	queue_redraw()

func _glow(at: Vector2, radius: int, color: Color, strength: float=.1) -> void:
	for i in range(4,0,-1):
		var c = color
		c.a = strength*(5-i)/4.0
		var r = radius*i/4.0
		draw_circle(at,r,c,true,-1,false)

func _night() -> void:
	for y in range(0,360,4):
		_rect(0,y,640,4,Color("10172e").lerp(Color("37535b"),y/360.0))
	for i in range(65):
		var x = fposmod(i*117.13-camera_x*.035,640)
		var y = 13+fposmod(i*i*5.73,139)
		_rect(x,y,1,1,Color(.83,.86,.75,.35+.2*sin(clock*.6+i)))
	var moon = Vector2(526-camera_x*.016,43)
	_glow(moon,41,Color("c6d7c2"),.025)
	for y in range(-17,18):
		for x in range(-17,18):
			if x*x+y*y<=289:
				_rect(moon.x+x,moon.y+y,1,1,Color("dbe0bc") if posmod(x*7+y*19,29)>3 else Color("b9c6ac"))
	# Silhouettes are distant; the playable route remains clearly outlined.
	for layer in range(2):
		var factor = .09+layer*.08
		for i in range(12):
			var x = fposmod(i*103-camera_x*factor,780)-100
			var top = 186+layer*30+sin(i*2.4)*19
			draw_colored_polygon(PackedVector2Array([Vector2(x-80,300),Vector2(x,top),Vector2(x+75,top+20),Vector2(x+145,300)]),Color("1e3545") if layer==0 else Color("23424c"))
	for i in range(9):
		var x = i*160-camera_x*.34
		if x < -120 or x > 760: continue
		var top = 152+posmod(i*29,44)
		_rect(x,top,8,155,Color("1a3541"))
		for j in range(4):
			_rect(x-30+j*9,top-10-j*8,70-j*13,16,Color("203c46"))
			_rect(x-27+j*18,top+4,3,24+j%2*13,Color("203c46"))
	_rect(0,305,640,55,WATER)
	for i in range(47):
		var x = fposmod(i*53-camera_x*.8+sin(clock*.6+i)*4,640)
		_rect(x,311+i%8*6,9+i%19,1,Color("315663"))
	for i in range(7):
		_rect(fposmod(i*139-camera_x*.22+clock*2,800)-100,211+i%3*24,110,2,Color(.6,.75,.75,.025))

func _bank(r: Rect2) -> void:
	_rect(r.position.x,300,r.size.x,90,Color("1a2d30"))
	_rect(r.position.x,300,r.size.x,5,Color("7c9367"))
	_rect(r.position.x,305,r.size.x,7,Color("435b46"))
	_rect(r.position.x,312,r.size.x,14,Color("263e36"))
	for x in range(int(r.position.x),int(r.end.x),9):
		if x < camera_x-12 or x > camera_x+652: continue
		var h = 3+posmod(x*7,8)
		_rect(x,300-h,2,h,Color("62805b"))
		if x%3 == 0: _rect(x+4,297-h,1,h+3,Color("8a9b6c"))
		if x%27 == 0:
			_rect(x,331+posmod(x,16),4,2,Color("344b43"))
			_rect(x+6,357,2,3,Color("10262c"))
	for x in [r.position.x,r.end.x-6]:
		_rect(x,306,6,11,Color("4c6650"))
		_rect(x+2,317,3,9,Color("344c42"))

func _wood(r: Rect2) -> void:
	_rect(r.position.x,r.position.y,r.size.x,3,Color("b0a17a"))
	_rect(r.position.x,r.position.y+3,r.size.x,6,Color("655b4d"))
	for x in range(int(r.position.x)+3,int(r.end.x)-2,13):
		_rect(x,r.position.y+1,1,6,Color("403e3b"))
		_rect(x+3,r.position.y+1,6,1,Color("cab98a"))

func _stone(r: Rect2, pier: bool=false) -> void:
	var h = 338-r.position.y if pier else r.size.y
	_rect(r.position.x+3,r.position.y+3,r.size.x-6,h,Color("36454a"))
	_rect(r.position.x,r.position.y,r.size.x,4,Color("8b9b85"))
	_rect(r.position.x+2,r.position.y+4,r.size.x-4,5,Color("617c70"))
	for y in range(int(r.position.y)+12,int(r.position.y+h),12):
		_rect(r.position.x+4,y,r.size.x-8,1,Color("273c41"))
		_rect(r.position.x+12+posmod(y*3,25),y-10,1,10,Color("4a5b59"))
	_rect(r.position.x+5,r.position.y+3,10,7,Color("6e895d"))
	_rect(r.end.x-17,r.position.y+2,9,4,Color("8fa06b"))

func _lantern(x: float, y: float, lit: bool=true) -> void:
	_rect(x-2,y+5,4,300-y-5,Color("505247"))
	_rect(x-6,y-9,12,2,Color("222e35"))
	_rect(x-8,y-7,16,3,Color("364348"))
	_rect(x-6,y-4,12,15,Color("263b40"))
	if lit:
		_glow(Vector2(x,y+3),33,GOLD,.045)
		_rect(x-4,y-2,8,10,Color("c6a16a"))
		_rect(x-2,y,4,6,Color("ffe4a1"))
	else: _rect(x-4,y-2,8,10,Color("62715f"))
	_rect(x-7,y+10,14,2,Color("22343a"))

func _willow(x: float) -> void:
	_rect(x-10,176,16,124,Color("344342"))
	_rect(x-6,181,4,108,Color("52604b"))
	_rect(x-18,291,34,9,Color("344342"))
	for i in range(5):
		_rect(x-56+i*12,147-i%3*9,100-i*12,20,Color("2d514d"))
	for i in range(10):
		var xx = x-55+i*12
		var length = 35+posmod(i*23,42)
		_rect(xx,163,3,length,Color("3e6355"))
		_rect(xx+2,180,2,length-12,Color("52725a"))
	# Small sleeping owl, purely decorative.
	_rect(x+14,176,10,12,Color("8a9380"))
	_rect(x+13,174,3,4,Color("8a9380"))
	_rect(x+22,174,3,4,Color("8a9380"))
	_rect(x+15,180,3,1,Color("273b40"))
	_rect(x+20,180,3,1,Color("273b40"))
	_rect(x+18,183,2,2,GOLD)
	_rect(x+6,189,28,4,Color("4c5244"))

func _cottage() -> void:
	var x = 4490.0
	# Stone foundations and muted wooden siding, under a stepped slate roof.
	_rect(x,134,238,166,Color("33474b"))
	for y in range(142,289,13):
		_rect(x+3,y,232,1,Color("263b41"))
		_rect(x+3,y+1,232,1,Color("3b5051"))
	_rect(x-4,282,246,18,Color("51605b"))
	for i in range(14):
		_rect(x-18+i*9,127-i*5,274-i*18,6,Color("263540"))
		_rect(x-18+i*9,127-i*5,6,2,Color("596166"))
	_rect(x+178,71,20,45,Color("475253"))
	_rect(x+175,68,26,5,Color("68726a"))
	for i in range(4):
		var t = fposmod(clock*.24+i*.25,1)
		_rect(x+180+sin(t*5)*6,65-t*38,11+t*14,5+t*5,Color(.6,.68,.68,(1-t)*.12))
	_rect(x+32,215,37,67,Color("1e3038"))
	_rect(x+34,217,33,65,Color("293c42"))
	_rect(x+59,251,2,2,GOLD)
	# The only entry is the open, warm window above the sill.
	_rect(WINDOW.position.x-5,WINDOW.position.y-5,52,61,Color("9a8d6d"))
	draw_rect(WINDOW,Color("b89462"))
	_rect(4598,175,34,43,Color("ecd29a"))
	_rect(4628,176,4,40,Color("c5a275"))
	_rect(4598,175,6,43,Color("e1bf84"))
	_rect(4600,188,3,22,Color("d1ad76"))
	for sx in [4579,4638]:
		_rect(sx,169,12,54,Color("52685e"))
		for yy in range(173,219,8): _rect(sx+2,yy,8,2,Color("344c48"))
	# Hinged casement opened outward, with no pane blocking the aperture.
	draw_colored_polygon(PackedVector2Array([Vector2(4635,172),Vector2(4647,181),Vector2(4647,213),Vector2(4635,222)]),Color("afaa83"))
	draw_colored_polygon(PackedVector2Array([Vector2(4638,179),Vector2(4644,184),Vector2(4644,209),Vector2(4638,215)]),Color("728779"))
	_rect(4592,170,46,3,Color("ead4a1"))
	# Light spills down and left, onto the last stepping stones.
	for i in range(3):
		var c = Color("f3cd82")
		c.a = .035+i*.018+sin(clock*1.2)*.005
		draw_colored_polygon(PackedVector2Array([Vector2(4594,178+i*4),Vector2(4634,219),Vector2(4480-i*40,300),Vector2(4410-i*35,300)]),c)
	_glow(WINDOW.get_center(),53,GOLD,.04)
	_rect(4570,222,84,3,Color("e2c795"))
	_rect(4572,225,80,7,Color("7b7560"))
	# A pale path below the window and a pot safely beside the facade.
	for i in range(6): _rect(4520+i*28,297,18,3,Color("9b9b7a"))
	_rect(4748,284,15,16,Color("796355"))
	_rect(4745,282,21,4,Color("a18769"))
	for i in range(3):
		_rect(4750+i*4,272-i%2*7,2,12+i%2*7,MOSS)
		_rect(4748+i*4,270-i%2*7,5,3,Color("b7b79a"))

func _scenery() -> void:
	# A few landmarks leave plenty of negative space around the route.
	for x in [90,1020,1990,3150]:
		if x+90 < camera_x or x-90 > camera_x+640: continue
		for i in range(6):
			var xx = x+i*9
			var h = 17+posmod(i*19,23)
			_rect(xx,300-h,2,h,Color("486957"))
			_rect(xx-2,296-h,5,10,Color("897b5b"))
	if camera_x > 1400 and camera_x < 2280: _willow(2110)
	for l in [[555,254],[1080,254],[REST.x,239],[3470,252],[4160,253]]:
		if l[0] > camera_x-45 and l[0] < camera_x+685:
			_lantern(l[0],l[1],checkpoint if l[0]==REST.x else true)
	if camera_x > 3800: _cottage()

func _murphy(at: Vector2, moving: bool) -> void:
	var palette = Art.palette("cat")
	var width = murphy_pixels[0].length()
	var bob = floorf(sin(clock*16)*1.2) if moving else 0.0
	for y in range(murphy_pixels.size()):
		var row = murphy_pixels[y]
		for x in range(row.length()):
			if not palette.has(row[x]): continue
			var px = width-1-x if facing > 0 else x
			var point = Vector2(px-width/2.0,y-murphy_pixels.size()+bob)
			if moving and y > murphy_pixels.size()-4:
				point.x += floorf(sin(clock*16+(0 if x < width/2 else PI))*1.5)
			draw_rect(Rect2((at+point).floor(),Vector2.ONE),palette[row[x]])

func _duo(at: Vector2, moving: bool) -> void:
	var lift = floorf(sin(clock*16)*1.2) if moving else 0.0
	_murphy(at,moving)
	_sprite("toad",at+Vector2(RIDER_OFFSET.x*facing,RIDER_OFFSET.y+lift),facing,1,false)
	if tongue_time > 0:
		var mouth = at+Vector2(RIDER_OFFSET.x*facing,RIDER_OFFSET.y-11+lift)
		var t = sin(clampf(tongue_time/.22,0,1)*PI)
		draw_line(mouth,mouth.lerp(tongue_tip,t),Color("cb8c96"),2,false)

func _draw() -> void:
	_night()
	draw_set_transform(Vector2(-floorf(camera_x),0))
	_scenery()
	for p in platforms:
		var r: Rect2 = p.rect
		if r.end.x < camera_x-24 or r.position.x > camera_x+664: continue
		match p.kind:
			"earth": _bank(r)
			"board": _wood(r)
			"stone": _stone(r)
			"step":
				_rect(r.position.x,r.position.y,r.size.x,r.size.y,Color("66654c"))
				_rect(r.position.x,r.position.y,r.size.x,3,Color("a4aa78"))
				_rect(r.position.x+3,r.position.y+5,2,r.size.y-8,Color("807d59"))
			"pier": _stone(r,true)
			"lily":
				_rect(r.position.x+6,r.position.y,r.size.x-12,3,Color("a3ad72"))
				_rect(r.position.x,r.position.y+3,r.size.x,4,Color("69895a"))
				_rect(r.position.x+5,r.position.y+7,r.size.x-10,3,Color("3e6751"))
				_rect(r.position.x+20,r.position.y+1,3,6,Color("42674e"))
				_rect(r.position.x+18,r.position.y+4,8,2,Color("42674e"))
				_rect(r.get_center().x,309,r.size.x*.35,1,Color("42646a"))
	for fly in flies:
		if collected.has(fly.id) or absf(fly.pos.x-camera_x-320)>350: continue
		var p: Vector2 = fly.pos + Vector2(sin(clock*1.5+fly.id)*2,sin(clock*2+fly.id)*2)
		_glow(p,10,GOLD,.06)
		_rect(p.x-1,p.y-1,3,3,Color("ffe7a6"))
		_rect(p.x-3,p.y-1,2,1,Color("9eae81"))
		_rect(p.x+2,p.y-1,2,1,Color("9eae81"))
	for e in enemies:
		if (e.alive or e.falling) and absf(e.pos.x-camera_x-320)<360:
			_sprite("skunk",e.pos,e.dir,1,e.alive,e.spin if e.falling else 0)
	if mode not in ["respawn","finish_menu"]:
		if mode != "home" or mode_time < 1.3:
			if mode == "home":
				var scale = 1.0-smoothstep(.25,1.3,mode_time)*.8
				draw_set_transform(Vector2(-floorf(camera_x),0)+player.position,0,Vector2.ONE*scale)
				_duo(Vector2(0,17),true)
				draw_set_transform(Vector2(-floorf(camera_x),0))
			else: _duo(player.position+Vector2(0,17),absf(player.velocity.x)>20 and player.is_on_floor())
	for p in particles:
		var c: Color = p.color
		c.a = clampf(p.life/.4,0,1)
		_rect(p.pos.x,p.pos.y,2,2,c)
	draw_set_transform(Vector2.ZERO)
	# A quiet HUD. No controls obscure the destination.
	_rect(12,12,127,23,Color(.035,.07,.1,.8))
	_text("LUCIOLES  %02d / 20"%score,Vector2(22,21),GOLD)
	if checkpoint:
		_rect(146,12,9,23,Color(.035,.07,.1,.8))
		_rect(149,21,3,5,GOLD)
	if toast_time > 0 and mode=="play":
		_text(toast,Vector2(320,53),GOLD,1,true)
	if player.position.x < 350 and mode=="play":
		_text("< > AVANCER    HAUT : SAUTER    ESPACE : LANGUE",Vector2(320,338),WHITE,1,true)
	if mode == "intro":
		_rect(0,0,640,360,Color(.02,.04,.08,.55))
		_text("CHAPITRE II",Vector2(320,98),MOSS,1,true)
		_text("LA LISIERE",Vector2(320,123),WHITE,4,true)
		_text("DES LANTERNES",Vector2(320,153),GOLD,3,true)
		_text("UNE LUMIERE VEILLE ENCORE, DE L'AUTRE COTE.",Vector2(320,197),WHITE,1,true)
		_text("ENTREE POUR PARTIR",Vector2(320,231),GOLD,2,true)
		_text("FLECHES : AVANCER / SAUTER    ESPACE : LANGUE",Vector2(320,286),WHITE,1,true)
		_text("ECHAP : PAUSE",Vector2(320,301),MOSS,1,true)
	elif mode == "pause":
		_rect(0,0,640,360,Color(.02,.04,.08,.75))
		_text("PETITE PAUSE",Vector2(320,143),GOLD,3,true)
		_button(title_button,"REPRENDRE")
	elif mode == "respawn":
		_rect(0,0,640,360,Color(.04,.08,.12,.22))
		_text("ON REPREND...",Vector2(320,147),WHITE,2,true)
	elif mode == "home" and mode_time > 1.4:
		_rect(164,117,312,35,Color(.035,.07,.1,.9))
		_text("CETTE FOIS, C'EST LA BONNE.",Vector2(320,131),GOLD,2,true)
	elif mode == "finish_menu":
		_rect(0,0,640,360,Color(.02,.04,.08,.78))
		_text("LA LUMIERE ETAIT POUR VOUS.",Vector2(320,96),MOSS,1,true)
		_text("A LA MAISON !",Vector2(320,129),GOLD,4,true)
		_text("MURPHY ET LE CRAPAUD SONT BIEN RENTRES.",Vector2(320,181),WHITE,1,true)
		_text("%d / 20 LUCIOLES RAMENEES"%score,Vector2(320,207),GOLD,2,true)
		_button(retry_button,"REJOUER")
		_button(exit_button,"REVENIR AUX PHOTOS")
